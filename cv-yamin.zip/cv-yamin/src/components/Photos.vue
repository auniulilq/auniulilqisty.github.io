<template>
    <div>
        photos
    </div>
</template>
<script>
export default {
    name:"Photos"
}
</script>